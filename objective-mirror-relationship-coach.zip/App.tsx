
import React, { useState, useEffect, useCallback } from 'react';
import { OperatingMode, MetricPoint, FactRecord, MemoryTier, Intervention, PortalMessage, EvidenceItem, User, TravelFundEntry } from './types';
import Dashboard from './components/Dashboard';
import FactLedger from './components/FactLedger';
import HouseholdConstitution from './components/HouseholdConstitution';
import LiveSession from './components/LiveSession';
import UsersTab from './components/UsersTab';
import { GoogleGenAI, Modality } from '@google/genai';
import { Shield, LayoutDashboard, Database, Scale, Settings, Bell, Watch, Activity, Wind, Users as UsersIcon } from 'lucide-react';

const HALO_GREETING = "Hi, I’m HALO. This is your 'Ask me anything?' space—part private vault, part therapist, and part fact-checker. You can: Vent your heart out (Start with 'Private' to keep it for your eyes only), Settle a doubt (Drop a screenshot or photo), or Recall reality (Ask me what was actually said during an argument). What’s on your mind right now?";

// Audio Decoding Helper
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'live' | 'ledger' | 'constitution'>('dashboard');
  const [mode, setMode] = useState<OperatingMode>(OperatingMode.DETECTOR);
  const [isPrivacyMode, setIsPrivacyMode] = useState(false);
  const [stressLevel, setStressLevel] = useState(22);
  const [vibeScore, setVibeScore] = useState(85);
  const [metrics, setMetrics] = useState<MetricPoint[]>([]);
  const [ledger, setLedger] = useState<FactRecord[]>([]);
  const [interventions, setInterventions] = useState<Intervention[]>([]);
  const [travelFundHistory, setTravelFundHistory] = useState<TravelFundEntry[]>([]);
  const [travelFundBalance, setTravelFundBalance] = useState(340);
  
  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      name: 'Alex',
      role: 'Partner A',
      biometricStatus: 'linked',
      voiceStatus: 'recorded',
      visionStatus: 'mapped',
      hrvBaseline: 55,
      lastStress: 22
    }
  ]);

  const [portalMessages, setPortalMessages] = useState<PortalMessage[]>([
    {
      id: 'greeting',
      timestamp: new Date().toISOString(),
      text: HALO_GREETING,
      role: 'halo',
      isPrivate: false,
      type: 'status'
    }
  ]);
  const [evidenceItems, setEvidenceItems] = useState<EvidenceItem[]>([]);
  const [isCoolingDown, setIsCoolingDown] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Sync mode and vibe score with stress level
  useEffect(() => {
    if (stressLevel > 70) setMode(OperatingMode.JUDGE);
    else if (stressLevel > 40) setMode(OperatingMode.COACH);
    else setMode(OperatingMode.DETECTOR);

    setVibeScore(prev => {
      const targetVibe = 100 - stressLevel;
      return prev + (targetVibe - prev) * 0.1;
    });
  }, [stressLevel]);

  // Simulation loop
  useEffect(() => {
    const interval = setInterval(() => {
      if (activeTab !== 'live' && !isCoolingDown) {
        setStressLevel(prev => {
          const next = prev + (Math.random() * 4 - 2);
          return Math.max(10, Math.min(100, next));
        });
      }
    }, 4000);

    const now = Date.now();
    setMetrics(Array.from({ length: 40 }, (_, i) => ({
      timestamp: now - (40 - i) * 60000,
      stressLevel: 20 + Math.random() * 20,
      vibeScore: 80,
      volumeLevel: 30,
      volatilityIndex: 2,
      sentiment: 'neutral'
    })));

    return () => clearInterval(interval);
  }, [activeTab, isCoolingDown]);

  const addIntervention = (intervention: Intervention) => {
    setInterventions(prev => [intervention, ...prev].slice(0, 10));
    if (intervention.type === 'circuit_breaker') triggerCoolDown();
    if (intervention.type === 'travel_fund_alert' && intervention.travelFundImpact) {
      triggerTravelFundInvestment(intervention.travelFundImpact, intervention.reasoning, intervention.message);
    }
  };

  const triggerTravelFundInvestment = (amount: number, reason: string, rule?: string) => {
    const entry: TravelFundEntry = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      amount,
      reason,
      ruleViolated: rule
    };
    setTravelFundHistory(prev => [entry, ...prev]);
    setTravelFundBalance(prev => prev + amount);
  };

  const triggerCoolDown = () => {
    setIsCoolingDown(true);
    setTimeout(() => setIsCoolingDown(false), 8000);
  };

  const addLedgerEntry = (entry: FactRecord) => {
    setLedger(prev => [entry, ...prev].slice(0, 100));
  };

  const enrollPartner = (data: Partial<User>) => {
    const newUser: User = {
      id: Date.now().toString(),
      name: data.name || 'Partner B',
      role: 'Partner B',
      biometricStatus: 'linked',
      voiceStatus: 'recorded',
      visionStatus: 'mapped',
      hrvBaseline: 60,
      lastStress: 20,
      ...data
    };
    setUsers(prev => [...prev, newUser]);
    
    // Trigger personalized welcome
    const personalizedWelcome = `Hi ${newUser.name}. I recognize your voice. I’m monitoring your HRV and it looks like your stress is peaking. I’ve opened your Private Tree Hole if you need to vent, or we can look at the Live Analysis together. What do you need?`;
    setPortalMessages(prev => [...prev, {
      id: 'welcome-' + newUser.id,
      timestamp: new Date().toISOString(),
      text: personalizedWelcome,
      role: 'halo',
      isPrivate: false,
      type: 'status'
    }]);
  };

  const blobToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleSpeakText = async (text: string) => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say with a calm, empathetic mediator tone: ${text}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' }, // Kore is warm/mediator style
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const audioBuffer = await decodeAudioData(decodeBase64(base64Audio), audioCtx, 24000, 1);
        const source = audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioCtx.destination);
        source.onended = () => setIsSpeaking(false);
        source.start();
      } else {
        setIsSpeaking(false);
      }
    } catch (error) {
      console.error("TTS failed:", error);
      setIsSpeaking(false);
    }
  };

  const handlePortalSendMessage = async (text: string, isPrivate: boolean, file?: File) => {
    const isVenting = isPrivate || text.toLowerCase().startsWith('private');
    const recognizedUser = users[0]?.name || "User";

    const userMsg: PortalMessage = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      text: file ? `[SUMMONING ARTIFACT]` : text,
      role: 'user',
      isPrivate: isVenting,
      type: file ? 'summon' : 'vent'
    };
    setPortalMessages(prev => [...prev, userMsg]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let haloResponseText = "";
      let analysisText = "";

      if (file) {
        const base64 = await blobToBase64(file);
        const imageUrl = URL.createObjectURL(file);
        
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: [
            {
              parts: [
                { inlineData: { data: base64, mimeType: file.type } },
                { text: `Role: HALO Forensic Analyst. Task: Analyze this screenshot or photo. Identified User: ${recognizedUser}.
                
                1. If Screenshot: Identify tone (gaslighting, aggression, passive-aggression) and linguistic patterns. 
                2. If Photo: Verify household state against chores/rules.
                3. Constitution Enforcement: Cross-reference with the Household Constitution (Rule 1: Trash, Rule 2: Chore Assistance, Rule 3: Sarcasm, Rule 4: Sentiment Integrity).
                4. Penalty/Reframing: If a rule violation is detected, frame it as an 'Investment in the Future' for the Shared Travel Fund. Suggest a $10 investment. 
                5. Amendment: If a conflict is observed that is NOT covered by the rules, suggest a new 'Amendment'.
                
                Keep results clinical, grounded, and objective but use the 'Travel Fund' reframing for violations.` }
              ]
            }
          ]
        });
        
        analysisText = response.text || "Distillation failure.";
        haloResponseText = "Forensic analysis synchronized. I've tagged the evidence in your tray and checked against the Constitution.";
        
        // Simple logic to detect if AI suggested a fund contribution
        if (analysisText.toLowerCase().includes('travel fund') || analysisText.toLowerCase().includes('$10')) {
          triggerTravelFundInvestment(10, "Forensic artifact analysis detected Constitution deviation.", "Rule Alignment Investment");
        }

        const evidence: EvidenceItem = {
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          imageUrl,
          type: file.type.includes('screenshot') || text.toLowerCase().includes('screenshot') ? 'screenshot' : 'photo',
          analysisTags: analysisText.length > 50 ? ['RULE_SYNC', 'INVESTMENT_TAGGED'] : ['ARTIFACT_LOGGED'],
          findings: analysisText
        };
        setEvidenceItems(prev => [evidence, ...prev].slice(0, 3));
      } else {
        const systemPrompt = isVenting 
          ? `Role: HALO Sanctuary (The Tree Hole). User Context: ${recognizedUser}. Task: Be empathetic, grounded. Acknowledge this is locked in the private vault. If they mention a conflict, check for Constitution rule violations or suggest a new Amendment. If a rule is violated, frame a $10 'Travel Fund Investment'.`
          : `Role: HALO Mediator. User Context: ${recognizedUser}. Task: Use data from the ledger and constitution to provide objective clarity. Always frame behavioral corrections as 'Investments in your Shared Travel Fund'.`;
          
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: [{ parts: [{ text: `${systemPrompt}\nUser says: ${text}` }] }]
        });
        haloResponseText = response.text || "Portal sync timeout.";
        
        if (haloResponseText.toLowerCase().includes('travel fund') || haloResponseText.toLowerCase().includes('$10')) {
          triggerTravelFundInvestment(10, "Linguistic pattern analysis detected Constitution deviation.", "Communication Investment");
        }
      }

      setPortalMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        timestamp: new Date().toISOString(),
        text: haloResponseText,
        role: 'halo',
        isPrivate: isVenting,
        type: file ? 'summon' : 'vent',
        analysis: analysisText
      }]);

    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="flex h-screen bg-[#020617] text-slate-100 overflow-hidden font-sans relative">
      {isCoolingDown && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center backdrop-blur-3xl bg-slate-950/80 animate-in fade-in duration-1000">
           <div className="relative flex items-center justify-center mb-12">
            <div className="w-64 h-64 rounded-full border border-teal-500/30 animate-[ping_4s_linear_infinite]"></div>
            <div className="absolute w-48 h-48 rounded-full border border-teal-500/50 animate-[ping_3s_linear_infinite] delay-700"></div>
            <div className="absolute w-32 h-32 rounded-full bg-teal-500/20 border border-teal-500/50 shadow-[0_0_50px_rgba(45,212,191,0.3)] flex items-center justify-center">
              <Wind size={40} className="text-teal-400 opacity-80 animate-pulse" />
            </div>
          </div>
          <h2 className="text-3xl font-black tracking-[0.4em] text-white mb-4 uppercase">Reseting Harmonics</h2>
          <p className="text-teal-400 font-bold uppercase tracking-widest text-sm animate-pulse">HALO Empathy Buffer Calibration...</p>
        </div>
      )}

      <div className={`fixed inset-0 pointer-events-none transition-all duration-1000 opacity-20 blur-[120px] ${
        mode === OperatingMode.JUDGE ? 'bg-red-600' : mode === OperatingMode.COACH ? 'bg-amber-600' : 'bg-teal-600'
      }`}></div>

      <aside className="w-20 md:w-72 glass border-r border-white/5 flex flex-col h-full z-30">
        <div className="p-8 flex flex-col gap-1">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-2xl transition-all duration-500 ${
              mode === OperatingMode.JUDGE ? 'bg-red-500' : mode === OperatingMode.COACH ? 'bg-amber-500' : 'bg-teal-500'
            }`}>
              <Shield size={24} strokeWidth={2.5} />
            </div>
            <div className="hidden md:block">
              <h1 className="text-2xl font-black tracking-tighter text-white uppercase">HALO</h1>
            </div>
          </div>
          <p className="hidden md:block text-[9px] text-slate-500 font-black uppercase tracking-[0.2em] mt-1">Relationship Portal v4.2</p>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          <SidebarItem icon={<LayoutDashboard size={20} />} label="Overview" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <SidebarItem icon={<UsersIcon size={20} />} label="Users" active={activeTab === 'users'} onClick={() => setActiveTab('users')} />
          <SidebarItem icon={<Activity size={20} />} label="Live Analysis" active={activeTab === 'live'} onClick={() => setActiveTab('live')} />
          <SidebarItem icon={<Database size={20} />} label="Memory Ledger" active={activeTab === 'ledger'} onClick={() => setActiveTab('ledger')} />
          <SidebarItem icon={<Scale size={20} />} label="Constitution" active={activeTab === 'constitution'} onClick={() => setActiveTab('constitution')} />
        </nav>

        <div className="p-6 border-t border-white/5 space-y-6">
          <div className="glass bg-white/5 p-4 rounded-2xl hidden md:block border border-white/10">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Active Wearable</span>
              <Watch size={14} className="text-teal-400" />
            </div>
            <div className="flex items-center gap-2 mt-2">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-[9px] text-emerald-400 font-bold uppercase leading-none">Biometrics Sync: High</span>
            </div>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto relative z-10">
        <header className="sticky top-0 z-20 glass border-b border-white/5 px-10 py-6 flex justify-between items-center">
          <div className="flex flex-col">
            <h2 className="text-sm font-black text-slate-500 uppercase tracking-[0.2em]">
              {activeTab === 'dashboard' ? 'HALO Dashboard' : 
               activeTab === 'users' ? 'Identity Layer' : 
               activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
            </h2>
            <p className="text-xs font-medium text-slate-400 mt-1 italic">
              "The Judge of facts. The Coach of hearts."
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className={`px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all duration-500 flex items-center gap-2 ${
              mode === OperatingMode.JUDGE ? 'bg-red-500/10 border-red-500/50 text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)]' :
              mode === OperatingMode.COACH ? 'bg-amber-500/10 border-amber-500/50 text-amber-500' :
              'bg-teal-500/10 border-teal-500/50 text-teal-400'
            }`}>
              <div className={`w-2 h-2 rounded-full ${mode === OperatingMode.JUDGE ? 'bg-red-500 animate-pulse' : mode === OperatingMode.COACH ? 'bg-amber-500' : 'bg-teal-500'}`} />
              {mode} MODE
            </div>
          </div>
        </header>

        <div className="p-10 max-w-7xl mx-auto">
          {activeTab === 'dashboard' && (
            <Dashboard 
              metrics={metrics} 
              interventions={interventions} 
              evidence={evidenceItems}
              portalMessages={portalMessages}
              onSendMessage={handlePortalSendMessage}
              onSpeakText={handleSpeakText}
              isSpeaking={isSpeaking}
              stressLevel={stressLevel}
              vibeScore={vibeScore}
              mode={mode}
              travelFundBalance={travelFundBalance}
            />
          )}
          {activeTab === 'users' && (
            <UsersTab users={users} onEnroll={enrollPartner} />
          )}
          {activeTab === 'live' && (
            <LiveSession 
              isPrivacyMode={isPrivacyMode} 
              onIntervention={addIntervention} 
              onLedgerEntry={addLedgerEntry} 
              onModeChange={setMode} 
              onStressUpdate={setStressLevel}
            />
          )}
          {activeTab === 'ledger' && <FactLedger records={ledger} />}
          {activeTab === 'constitution' && (
            <HouseholdConstitution 
              fundBalance={travelFundBalance} 
              fundHistory={travelFundHistory} 
            />
          )}
        </div>
      </main>
    </div>
  );
};

const SidebarItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick} 
    className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-[1.25rem] transition-all duration-300 group ${
      active 
        ? 'bg-white/10 text-white border border-white/10 shadow-lg shadow-black/20' 
        : 'text-slate-500 hover:text-slate-200 hover:bg-white/5'
    }`}
  >
    <span className={active ? 'text-white' : 'text-slate-500'}>{icon}</span>
    <span className="hidden md:block text-sm font-bold tracking-tight">{label}</span>
    {active && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_8px_white]" />}
  </button>
);

export default App;
