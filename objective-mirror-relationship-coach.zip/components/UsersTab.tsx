
import React, { useState } from 'react';
import { User } from '../types';
import { Watch, Mic, Camera, ShieldCheck, UserPlus, Fingerprint, Activity, Zap, Info } from 'lucide-react';

interface UsersTabProps {
  users: User[];
  onEnroll: (user: Partial<User>) => void;
}

const UsersTab: React.FC<UsersTabProps> = ({ users, onEnroll }) => {
  const [isEnrolling, setIsEnrolling] = useState(false);

  const enrollmentSteps = [
    { icon: <Watch size={18} />, label: 'HealthKit Binding', desc: 'Sync HRV & Heart Rate baselines' },
    { icon: <Mic size={18} />, label: 'Voice Fingerprint', desc: 'Record Grounding Statement' },
    { icon: <Camera size={18} />, label: 'Skeletal Mapping', desc: 'Privacy-first proximity mesh' },
  ];

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tight uppercase">Identity Layer</h2>
          <p className="text-slate-400 mt-2 font-medium">Binding biological signatures to HALO's Mediator Core.</p>
        </div>
        <button 
          onClick={() => setIsEnrolling(true)}
          className="px-6 py-3 bg-indigo-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-xl shadow-indigo-500/20 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
        >
          <UserPlus size={16} /> Enroll New Partner
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {users.map((user) => (
          <div key={user.id} className="glass p-10 rounded-[2.5rem] border border-white/5 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:opacity-[0.07] transition-opacity">
              <Fingerprint size={120} />
            </div>
            
            <div className="flex items-center gap-6 mb-10">
              <div className="w-20 h-20 rounded-3xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                <span className="text-3xl font-black">{user.name.charAt(0)}</span>
              </div>
              <div>
                <h3 className="text-2xl font-black text-white tracking-tight">{user.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 text-[8px] font-black uppercase tracking-widest rounded border border-indigo-500/20">
                    {user.role}
                  </span>
                  <div className="flex items-center gap-1 text-[8px] font-black text-teal-400 uppercase tracking-widest">
                    <Activity size={10} /> Active Pulse
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 mb-10">
              <StatusCard 
                icon={<Watch size={16} />} 
                label="Biometrics" 
                status={user.biometricStatus} 
              />
              <StatusCard 
                icon={<Mic size={16} />} 
                label="Acoustics" 
                status={user.voiceStatus} 
              />
              <StatusCard 
                icon={<Camera size={16} />} 
                label="Vision" 
                status={user.visionStatus} 
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                <span className="text-slate-500">HRV Baseline Alignment</span>
                <span className="text-white">{user.hrvBaseline} ms</span>
              </div>
              <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 w-[78%] rounded-full shadow-[0_0_10px_rgba(99,102,241,0.5)]" />
              </div>
              <p className="text-[9px] text-slate-500 italic font-medium leading-relaxed">
                HALO uses this baseline to detect fight-or-flight triggers before verbal escalation occurs.
              </p>
            </div>

            <div className="mt-8 pt-8 border-t border-white/5 flex gap-4">
              <button className="flex-1 py-3 glass bg-white/5 hover:bg-white/10 rounded-xl text-[9px] font-black uppercase tracking-widest text-slate-400 transition-all border border-white/5">
                Recalibrate
              </button>
              <button className="flex-1 py-3 glass bg-white/5 hover:bg-white/10 rounded-xl text-[9px] font-black uppercase tracking-widest text-slate-400 transition-all border border-white/5">
                View Patterns
              </button>
            </div>
          </div>
        ))}

        {users.length < 2 && (
          <div className="glass p-10 rounded-[2.5rem] border border-white/5 border-dashed flex flex-col items-center justify-center text-center opacity-50 hover:opacity-100 transition-opacity cursor-pointer group" onClick={() => setIsEnrolling(true)}>
            <div className="w-16 h-16 rounded-full border-2 border-dashed border-white/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <UserPlus size={24} className="text-slate-500" />
            </div>
            <h4 className="text-lg font-black text-white uppercase tracking-widest mb-2">Enroll Partner B</h4>
            <p className="text-xs text-slate-500 font-medium max-w-[200px]">Complete the dyadic loop for full mediator functionality.</p>
          </div>
        )}
      </div>

      <div className="glass p-8 rounded-[2.5rem] border border-white/5 bg-indigo-500/5">
        <div className="flex items-start gap-6">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 flex items-center justify-center shrink-0">
            <Zap size={24} className="text-indigo-400" />
          </div>
          <div>
            <h4 className="text-sm font-black text-white uppercase tracking-widest mb-2">Vision Enrollment: Privacy Protocol</h4>
            <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
              Our Google Nest integration does not store facial pixels. Instead, HALO maps a <strong>Skeletal Mesh</strong> using proximity sensors to identify users based on height, gait, and movement patterns. This allows the system to verify "Household Constitution" actions (like dish-washing or door slamming) while maintaining absolute visual privacy.
            </p>
            <div className="flex gap-4 mt-6">
              {enrollmentSteps.map((step, i) => (
                <div key={i} className="flex-1 bg-white/5 p-4 rounded-2xl border border-white/5">
                  <div className="text-indigo-400 mb-2">{step.icon}</div>
                  <p className="text-[10px] font-black text-white uppercase tracking-widest mb-1">{step.label}</p>
                  <p className="text-[9px] text-slate-500 font-medium">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Fixed: StatusCard component's status prop needs to accept all possible status strings from User interface.
const StatusCard: React.FC<{ icon: React.ReactNode; label: string; status: 'linked' | 'recorded' | 'mapped' | 'pending' | 'none' }> = ({ icon, label, status }) => {
  const getStatusColor = () => {
    // Treat 'linked', 'recorded', and 'mapped' as completed states.
    if (status === 'linked' || status === 'recorded' || status === 'mapped') return 'text-teal-400';
    if (status === 'pending') return 'text-amber-400';
    return 'text-slate-600';
  };

  return (
    <div className="bg-white/5 border border-white/5 p-4 rounded-2xl text-center flex flex-col items-center gap-2">
      <div className={`${getStatusColor()} opacity-60`}>{icon}</div>
      <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">{label}</p>
      <div className={`flex items-center gap-1.5 text-[7px] font-black uppercase tracking-widest ${getStatusColor()}`}>
        {(status === 'linked' || status === 'recorded' || status === 'mapped') && <ShieldCheck size={8} />}
        {status}
      </div>
    </div>
  );
};

export default UsersTab;
