
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { OperatingMode, Intervention, FactRecord, MemoryTier } from '../types';
// Fixed: Removed 'BrainCircuit' from the lucide-react import to resolve conflict with local declaration.
import { Mic, MicOff, Video, VideoOff, ShieldOff, MessageSquare, HeartPulse, Watch, Camera, AlertCircle } from 'lucide-react';

interface LiveSessionProps {
  isPrivacyMode: boolean;
  onIntervention: (i: Intervention) => void;
  onLedgerEntry: (e: FactRecord) => void;
  onModeChange: (m: OperatingMode) => void;
  onStressUpdate: (s: number) => void;
}

// Minimal Audio Helpers
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const LiveSession: React.FC<LiveSessionProps> = ({ isPrivacyMode, onIntervention, onLedgerEntry, onModeChange, onStressUpdate }) => {
  const [isActive, setIsActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [sessionError, setSessionError] = useState<string | null>(null);
  const [transcription, setTranscription] = useState<string[]>([]);
  const [bpm, setBpm] = useState(72);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Simulated biometric spikes
  useEffect(() => {
    if (!isActive) return;
    const interval = setInterval(() => {
      const newBpm = 70 + Math.random() * 40;
      setBpm(Math.round(newBpm));
      
      if (newBpm > 100) {
        onStressUpdate(85);
        onIntervention({
          id: Date.now().toString(),
          timestamp: new Date().toISOString(),
          type: 'biometric_cooldown',
          reasoning: "Heart rate exceeds 100 BPM during seated mediation.",
          message: "Arousal spike detected. Please match my breathing pace.",
          volatilitySnapshot: 8.5
        });
      } else {
        onStressUpdate(30 + Math.random() * 20);
      }
    }, 15000);
    return () => clearInterval(interval);
  }, [isActive]);

  const startSession = async () => {
    try {
      setSessionError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: { width: 640, height: 480, frameRate: 15 } 
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 16000});
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
      const outputNode = outputAudioContext.createGain();
      outputNode.connect(outputAudioContext.destination);
      let nextStartTime = 0;
      const sources = new Set<AudioBufferSourceNode>();

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            const source = inputAudioContext.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              if (isMuted || isPrivacyMode) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              nextStartTime = Math.max(nextStartTime, outputAudioContext.currentTime);
              const buffer = await decodeAudioData(decode(audioData), outputAudioContext, 24000, 1);
              const source = outputAudioContext.createBufferSource();
              source.buffer = buffer;
              source.connect(outputNode);
              source.start(nextStartTime);
              nextStartTime += buffer.duration;
              sources.add(source);
              source.onended = () => sources.delete(source);
            }
            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              setTranscription(prev => [...prev, `HALO: ${text}`].slice(-6));
              
              // Agentic Logic: If HALO detects sarcasm or escalation in its own analysis
              if (text.toLowerCase().includes("sarcasm") || text.toLowerCase().includes("rule")) {
                onIntervention({
                  id: Date.now().toString(),
                  timestamp: new Date().toISOString(),
                  type: 'nudge',
                  reasoning: "HALO Linguistic Core detected behavioral rule violation.",
                  message: "Constraint violation: Sarcasm-Free Zone rule 3 is now active.",
                  volatilitySnapshot: 7.0
                });
              }
            }
            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              setTranscription(prev => [...prev, `User: ${text}`].slice(-6));
            }
            
            if (message.serverContent?.turnComplete) {
              // Commit to Ledger
              onLedgerEntry({
                id: Date.now().toString(),
                timestamp: new Date().toISOString(),
                speaker: 'Mediated Turn',
                content: transcription[transcription.length - 1] || "Interaction summary pending distillation.",
                tier: MemoryTier.TIER_1_BUFFER,
                hasConflictFlag: bpm > 100,
                isAnonymized: isPrivacyMode
              });
            }
          },
          onerror: (e) => setSessionError("Signal integrity compromised."),
          onclose: () => setIsActive(false),
        },
        config: {
          // Fixed: property name corrected to responseModalities from responseModalalities
          responseModalities: [Modality.AUDIO],
          systemInstruction: `You are HALO, an agentic mediator. 
          1. DETECT: Tone shift, volume escalation, and Rule 3 violations (Sarcasm).
          2. INTERVENE: If stress is visible, pause the conversation. 
          3. GROUND: Refer to Rule 1 (Trash Protocol) or Rule 4 (Sentiment Integrity) as needed.
          Tone: Clinical, warm, firm.`,
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      setSessionError("Biometric hardware denied.");
    }
  };

  const stopSession = () => {
    if (sessionRef.current) sessionRef.current.close();
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    setIsActive(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 h-full">
      <div className="lg:col-span-8 space-y-8">
        <div className="glass rounded-[2.5rem] overflow-hidden border border-white/5 relative aspect-video shadow-2xl group">
          <video ref={videoRef} autoPlay playsInline muted className={`w-full h-full object-cover transition-all duration-1000 ${isActive ? 'opacity-100' : 'opacity-0 grayscale blur-xl scale-110'}`} />
          
          {isPrivacyMode && (
            <div className="absolute inset-0 z-10 backdrop-blur-3xl bg-slate-950/80 flex flex-col items-center justify-center text-center p-12">
              <ShieldOff size={80} className="text-white/20 mb-6 animate-pulse" />
              <h4 className="text-2xl font-black uppercase tracking-tighter">Privacy Shield Active</h4>
              <p className="text-slate-400 font-medium max-w-xs mt-2">Manual override enabled. Multimodal data distillation paused.</p>
            </div>
          )}

          {!isActive && !sessionError && (
            <div className="absolute inset-0 flex items-center justify-center bg-slate-950/40 z-20">
              <button onClick={startSession} className="glass px-10 py-6 rounded-3xl font-black uppercase tracking-[0.2em] text-white flex items-center gap-4 hover:scale-105 transition-all shadow-2xl active:scale-95 border-white/20">
                <Camera size={24} />
                Initialize Feed
              </button>
            </div>
          )}

          {isActive && (
            <div className="absolute top-8 left-8 flex flex-col gap-4 z-20 opacity-0 group-hover:opacity-100 transition-opacity">
               <div className="glass px-4 py-2 rounded-2xl border border-white/10 flex items-center gap-3">
                 <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                 <span className="text-[10px] font-black text-white uppercase tracking-widest">Multi-modal Sync</span>
               </div>
               <div className="glass px-4 py-2 rounded-2xl border border-white/10 flex items-center gap-3">
                 <HeartPulse size={14} className={`${bpm > 100 ? 'text-red-500 animate-ping' : 'text-teal-400 animate-pulse'}`} />
                 <span className="text-[10px] font-black text-white uppercase tracking-widest">{bpm} BPM</span>
               </div>
            </div>
          )}

          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 glass px-10 py-4 rounded-[2.5rem] border border-white/10 flex items-center gap-8 shadow-2xl z-20 opacity-0 group-hover:opacity-100 transition-opacity">
             <LiveControl active={!isMuted} onClick={() => setIsMuted(!isMuted)} icon={isMuted ? <MicOff size={20} /> : <Mic size={20} />} label={isMuted ? "Muted" : "Active"} />
             <div className="w-[1px] h-8 bg-white/10" />
             <LiveControl active={!isVideoOff} onClick={() => setIsVideoOff(!isVideoOff)} icon={isVideoOff ? <VideoOff size={20} /> : <Video size={20} />} label={isVideoOff ? "Hidden" : "Live"} />
             <div className="w-[1px] h-8 bg-white/10" />
             <button onClick={stopSession} className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-black text-[10px] uppercase tracking-widest rounded-xl transition-all">
               Abort Session
             </button>
          </div>
        </div>

        {/* Real-time Transcription Glass */}
        <div className="glass p-10 rounded-[2.5rem] border border-white/5 h-[320px] flex flex-col shadow-2xl">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-sm font-black text-white uppercase tracking-[0.2em] flex items-center gap-3">
              <MessageSquare size={18} className="text-indigo-400" /> Temporal Distillation
            </h3>
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Buffer Status: {transcription.length}/6</span>
          </div>
          <div className="flex-1 space-y-6 overflow-y-auto pr-4 terminal-font scrollbar-hide">
            {transcription.length === 0 ? (
              <div className="h-full flex items-center justify-center text-slate-600 italic text-sm">
                Awaiting linguistic artifacts...
              </div>
            ) : (
              transcription.map((line, i) => (
                <div key={i} className={`flex gap-6 animate-in slide-in-from-left-2 duration-500`}>
                  <div className={`text-[10px] font-black mt-1 uppercase tracking-widest shrink-0 ${line.startsWith('HALO:') ? 'text-indigo-400' : 'text-slate-500'}`}>
                    {line.split(':')[0]}
                  </div>
                  <div className={`text-sm leading-relaxed p-4 rounded-2xl ${line.startsWith('HALO:') ? 'bg-indigo-500/10 text-indigo-100 border border-indigo-500/20 shadow-lg' : 'bg-white/5 text-slate-300'}`}>
                    {line.split(':').slice(1).join(':')}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <div className="lg:col-span-4 space-y-8">
        <div className="glass p-8 rounded-[2.5rem] border border-white/5 shadow-2xl flex flex-col items-center gap-6">
           <div className={`w-20 h-20 glass rounded-3xl border border-white/10 flex items-center justify-center transition-colors ${bpm > 100 ? 'text-rose-500 shadow-[0_0_20px_#ef444433]' : 'text-teal-400 shadow-inner'}`}>
             <Watch size={40} />
           </div>
           <div className="text-center">
             <h4 className="text-sm font-black text-white uppercase tracking-widest">Wearable Bridge</h4>
             <p className="text-xs font-medium text-slate-500 mt-1">Apple Watch Ultra</p>
           </div>
           <div className="grid grid-cols-2 gap-4 w-full">
             <BiometricMiniCard label="BPM" value={bpm} unit="pulse" />
             <BiometricMiniCard label="HRV" value={bpm > 100 ? 32 : 58} unit="ms" />
           </div>
           <div className={`w-full p-4 border rounded-2xl text-[10px] font-black uppercase tracking-widest text-center transition-all ${
             bpm > 100 ? 'bg-rose-500/10 border-rose-500/30 text-rose-400' : 'bg-teal-500/10 border-teal-500/20 text-teal-400'
           }`}>
             {bpm > 100 ? 'Fight-or-Flight Active' : 'Basal Activity: Consistent'}
           </div>
        </div>

        <div className="glass p-8 rounded-[2.5rem] border border-white/5 shadow-2xl space-y-6">
          <h3 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-3">
             <BrainCircuit size={18} className="text-indigo-400" /> Mediator Logic
          </h3>
          <div className="space-y-4">
             <ProtocolItem label="Vocal Stress Mapping" active={isActive} />
             <ProtocolItem label="Semantic Intent Filter" active={isActive} />
             <ProtocolItem label="Fight-or-Flight Nudge" active={bpm > 100} />
             <ProtocolItem label="Rule Citation Engine" active={isActive} />
          </div>
          <button className="w-full py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-400 transition-all border border-white/5">
            Calibrate Sensors
          </button>
        </div>
      </div>
    </div>
  );
};

const LiveControl: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button onClick={onClick} className="flex flex-col items-center gap-2 group">
    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${active ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20' : 'bg-white/5 text-slate-500'}`}>
      {icon}
    </div>
    <span className="text-[9px] font-black uppercase tracking-widest text-slate-500">{label}</span>
  </button>
);

const BiometricMiniCard: React.FC<{ label: string; value: string | number; unit: string }> = ({ label, value, unit }) => (
  <div className="bg-white/5 border border-white/5 p-4 rounded-2xl text-center">
    <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{label}</p>
    <p className="text-2xl font-black text-white tabular-nums">{value}</p>
    <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">{unit}</p>
  </div>
);

const ProtocolItem: React.FC<{ label: string; active: boolean }> = ({ label, active }) => (
  <div className={`flex items-center justify-between transition-opacity ${active ? 'opacity-100' : 'opacity-40'}`}>
    <span className="text-[11px] font-bold text-slate-300 uppercase tracking-tight">{label}</span>
    <div className={`w-1.5 h-1.5 rounded-full ${active ? 'bg-teal-400 shadow-[0_0_8px_#2dd4bf]' : 'bg-slate-700'}`} />
  </div>
);

// Local BrainCircuit declaration (conflicts with lucide-react import)
const BrainCircuit: React.FC<{ size?: number; className?: string }> = ({ size = 20, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 4.5a2.5 2.5 0 0 0-4.96-.46 2.5 2.5 0 0 0-1.98 3 2.5 2.5 0 0 0 .94 4.82 2.5 2.5 0 0 0 0 4.28 2.5 2.5 0 0 0-.94 4.82 2.5 2.5 0 0 0 1.98 3 2.5 2.5 0 0 0 4.96-.46" />
    <path d="M12 4.5a2.5 2.5 0 0 1 4.96-.46 2.5 2.5 0 0 1 1.98 3 2.5 2.5 0 0 1-.94 4.82 2.5 2.5 0 0 1 0 4.28 2.5 2.5 0 0 1 .94 4.82 2.5 2.5 0 0 1-1.98 3 2.5 2.5 0 0 1-4.96-.46" />
    <circle cx="12" cy="12" r="2" />
    <path d="M12 8v2" />
    <path d="M12 14v2" />
    <path d="M16 12h2" />
    <path d="M6 12h2" />
  </svg>
);

export default LiveSession;
