
import React from 'react';
import { ShieldCheck, BookOpen, Clock, AlertTriangle, HelpCircle, MessageSquare, Trash2, Users, Sparkles, Plane, History, DollarSign } from 'lucide-react';
import { TravelFundEntry } from '../types';

interface HouseholdConstitutionProps {
  fundBalance?: number;
  fundHistory?: TravelFundEntry[];
}

const HouseholdConstitution: React.FC<HouseholdConstitutionProps> = ({ fundBalance = 0, fundHistory = [] }) => {
  const rules = [
    { 
      id: '1', 
      title: 'Sunday Trash Protocol', 
      description: "'Taking the trash out' on Sunday nights implies checking the Kitchen, Bathroom, and Office. A partial sweep is considered an incomplete task.", 
      category: 'Labor Division', 
      priority: 'Medium',
      icon: <Trash2 size={20} className="text-slate-500" />
    },
    { 
      id: '2', 
      title: 'Active Chore Assistance', 
      description: 'If someone is cleaning a shared space, the other partner should offer to assist or take over a different chore to maintain labor equity.', 
      category: 'Shared Responsibility', 
      priority: 'Medium',
      icon: <Users size={20} className="text-indigo-500" />
    },
    { 
      id: '3', 
      title: 'Sarcasm-Free Resolution', 
      description: "No sarcasm is allowed during 'Issue Resolution' chats. Sarcastic tones will trigger an immediate communication 'Circuit Breaker'.", 
      category: 'Communication', 
      priority: 'High',
      icon: <MessageSquare size={20} className="text-rose-500" />
    },
    { 
      id: '4', 
      title: 'Sentiment Integrity', 
      description: "'I'm fine' is flagged as an 'Incomplete Sentiment' if Acoustic Stress (Pitch/Tone) is > 50%. Emotional transparency is required for coaching.", 
      category: 'Emotional Intelligence', 
      priority: 'High',
      icon: <Sparkles size={20} className="text-amber-500" />
    }
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Constitution Header */}
        <div className="lg:col-span-2 bg-indigo-900 rounded-[2.5rem] p-10 text-white relative overflow-hidden shadow-2xl flex flex-col justify-center">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <BookOpen size={140} />
          </div>
          <div className="relative z-10">
            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-6 backdrop-blur-xl border border-white/20">
              <ShieldCheck size={24} />
            </div>
            <h2 className="text-3xl font-black mb-4 tracking-tight uppercase">Household Constitution</h2>
            <p className="text-indigo-100 text-sm leading-relaxed font-medium opacity-90 max-w-lg">
              The fundamental behavioral framework. These rules empower HALO to provide "Grounded Truth" and mediate conflicts with objective context.
            </p>
            <div className="mt-8 flex gap-3">
              <button className="bg-white text-indigo-900 px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:scale-[1.02] transition-all active:scale-95">
                Propose Amendment
              </button>
            </div>
          </div>
        </div>

        {/* Travel Fund Widget */}
        <div className="bg-teal-900/40 rounded-[2.5rem] p-10 border border-teal-500/20 shadow-2xl relative overflow-hidden flex flex-col justify-center">
          <div className="absolute -bottom-10 -right-10 opacity-10 rotate-12">
            <Plane size={160} />
          </div>
          <div className="relative z-10 text-center">
            <h3 className="text-[10px] font-black text-teal-400 uppercase tracking-[0.3em] mb-4">Shared Travel Fund</h3>
            <div className="flex items-center justify-center gap-2 mb-2">
               <DollarSign size={24} className="text-teal-400" />
               <span className="text-5xl font-black text-white tracking-tighter tabular-nums">{fundBalance}</span>
            </div>
            <p className="text-[9px] font-black text-teal-400/60 uppercase tracking-widest">Recalibrating for Vacations</p>
            
            <div className="mt-8 pt-8 border-t border-teal-500/10 flex flex-col gap-4">
               <div className="flex items-center justify-between">
                  <span className="text-[8px] font-black text-teal-500/60 uppercase">Next Milestone</span>
                  <span className="text-[10px] font-black text-white">$500 (Beach Escape)</span>
               </div>
               <div className="w-full h-1 bg-teal-500/10 rounded-full overflow-hidden">
                  <div className="h-full bg-teal-400 rounded-full" style={{ width: `${(fundBalance / 500) * 100}%` }} />
               </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {rules.map((rule) => (
          <div key={rule.id} className="glass p-8 rounded-[2rem] border border-white/5 shadow-xl hover:border-indigo-500/30 transition-all group relative overflow-hidden">
            <div className="flex justify-between items-start mb-6">
              <div className="p-3 bg-white/5 rounded-xl group-hover:bg-indigo-500/10 transition-colors">
                {rule.icon}
              </div>
              <div className={`flex items-center gap-1.5 text-[8px] font-black uppercase tracking-widest ${
                rule.priority === 'High' ? 'text-rose-500' : 'text-amber-500'
              }`}>
                {rule.priority === 'High' ? <AlertTriangle size={12} /> : <HelpCircle size={12} />}
                {rule.priority} Priority
              </div>
            </div>
            <h3 className="text-lg font-black text-white mb-2 tracking-tight uppercase leading-tight">{rule.title}</h3>
            <p className="text-slate-500 leading-relaxed font-medium text-[11px] mb-6 line-clamp-3">{rule.description}</p>
            <div className="pt-6 border-t border-white/5 flex items-center justify-between text-[8px] font-black text-slate-600 uppercase tracking-widest">
              <span className="flex items-center gap-1"><Clock size={10} /> v1.2</span>
              <span className="text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity">Details</span>
            </div>
          </div>
        ))}
      </div>

      {/* Fund History / Recent Investments */}
      <div className="glass p-10 rounded-[2.5rem] border border-white/5 shadow-2xl">
        <div className="flex items-center gap-3 mb-8">
           <History size={20} className="text-indigo-400" />
           <h3 className="text-sm font-black text-white uppercase tracking-widest">Recalibration History (Travel Fund)</h3>
        </div>
        
        {fundHistory.length === 0 ? (
          <p className="text-xs text-slate-500 italic text-center py-10">No recent rule-alignment investments recorded.</p>
        ) : (
          <div className="space-y-4">
            {fundHistory.slice(0, 5).map(entry => (
              <div key={entry.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 group hover:bg-white/10 transition-all">
                <div className="flex items-center gap-4">
                   <div className="w-10 h-10 rounded-xl bg-teal-500/10 flex items-center justify-center text-teal-400 font-black">
                      +${entry.amount}
                   </div>
                   <div>
                      <p className="text-xs font-black text-white uppercase tracking-tight">{entry.ruleViolated || 'Protocol Alignment'}</p>
                      <p className="text-[10px] text-slate-500 font-medium">{entry.reason}</p>
                   </div>
                </div>
                <div className="text-right">
                   <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">
                      {new Date(entry.timestamp).toLocaleDateString()}
                   </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="glass p-10 rounded-[2.5rem] border border-white/5 shadow-xl bg-indigo-500/5">
        <div className="flex items-start gap-6">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 flex items-center justify-center shrink-0">
            <Sparkles size={24} className="text-indigo-400" />
          </div>
          <div>
            <h4 className="text-sm font-black text-white uppercase tracking-widest mb-2">The "Investment" Framework</h4>
            <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
              HALO does not issue "fines." When a Constitution deviation is detected, the AI triggers a mandatory contribution to your <strong>Shared Travel Fund</strong>. This reframes behavioral accountability as a shared investment in your relationship's future enjoyment rather than a punitive measure for past mistakes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HouseholdConstitution;
