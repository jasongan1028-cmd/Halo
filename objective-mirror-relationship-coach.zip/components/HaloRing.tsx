
import React from 'react';
import { OperatingMode } from '../types';

interface HaloRingProps {
  stressLevel: number;
  vibeScore: number;
  mode: OperatingMode;
}

const HaloRing: React.FC<HaloRingProps> = ({ stressLevel, vibeScore, mode }) => {
  const getColor = () => {
    if (mode === OperatingMode.JUDGE) return '#ef4444'; // Conflict / Red
    if (mode === OperatingMode.COACH) return '#f59e0b'; // Tension / Amber
    return '#2dd4bf'; // Calm / Teal
  };

  const color = getColor();

  return (
    <div className="relative flex items-center justify-center w-[300px] h-[300px] md:w-[400px] md:h-[400px]">
      {/* Pulse Rings */}
      <div 
        className="absolute w-full h-full rounded-full transition-all duration-1000 animate-[ping_4s_cubic-bezier(0,0,0.2,1)_infinite]"
        style={{ 
          backgroundColor: color,
          opacity: 0.1,
          filter: 'blur(30px)'
        }}
      />
      
      {/* Halo Core */}
      <div 
        className="relative w-[220px] h-[220px] md:w-[320px] md:h-[320px] rounded-full border-2 transition-all duration-1000 flex items-center justify-center glass shadow-2xl"
        style={{ 
          borderColor: `${color}44`,
          boxShadow: `0 0 60px ${color}22, inset 0 0 20px ${color}11`
        }}
      >
        {/* Progress Arc (Vibe Score) */}
        <svg className="absolute inset-0 w-full h-full -rotate-90">
          <circle
            cx="50%"
            cy="50%"
            r="48%"
            stroke={color}
            strokeWidth="6"
            fill="transparent"
            strokeDasharray="100%"
            strokeDashoffset={`${100 - vibeScore}%`}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-in-out"
            style={{ filter: `drop-shadow(0 0 15px ${color})`, strokeDasharray: '314%', strokeDashoffset: (314 * (1 - vibeScore / 100)) }}
          />
        </svg>

        {/* Inner Content */}
        <div className="flex flex-col items-center justify-center text-center">
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-1">Vibe Score</span>
          <div className="flex items-baseline gap-1">
            <span className="text-6xl md:text-7xl font-black text-white tracking-tighter tabular-nums">
              {Math.round(vibeScore)}
            </span>
            <span className="text-xl font-bold text-slate-500">%</span>
          </div>
          <div 
            className="mt-4 px-4 py-1 rounded-full border text-[9px] font-black uppercase tracking-widest transition-all duration-500"
            style={{ 
              borderColor: `${color}66`,
              color: color,
              backgroundColor: `${color}11`
            }}
          >
            {mode === OperatingMode.JUDGE ? 'Active Conflict' : mode === OperatingMode.COACH ? 'Coaching Mode' : 'Harmony Secure'}
          </div>
        </div>
      </div>

      {/* Satellite Indicators */}
      <div className="absolute -top-6 right-0 glass px-3 py-1.5 rounded-xl border border-white/10 flex items-center gap-2">
        <div className="w-1.5 h-1.5 bg-teal-400 rounded-full animate-pulse" />
        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Ambient Sync</span>
      </div>
    </div>
  );
};

export default HaloRing;
