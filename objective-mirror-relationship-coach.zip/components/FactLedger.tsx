
import React, { useState } from 'react';
import { FactRecord, MemoryTier } from '../types';
// Fix: Import 'Database' from 'lucide-react' as it is used in the empty state view.
import { Search, Filter, Download, ShieldCheck, Clock, ShieldAlert, Zap, Database } from 'lucide-react';

interface FactLedgerProps {
  records: FactRecord[];
}

const FactLedger: React.FC<FactLedgerProps> = ({ records }) => {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-500">
      <div className="p-10 border-b border-slate-100">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-10">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-3xl font-black text-slate-900 tracking-tight">Memory Vault</h3>
              <span className="px-3 py-1 bg-indigo-50 text-indigo-700 text-[10px] font-bold rounded-full uppercase tracking-widest border border-indigo-100">Immutable</span>
            </div>
            <p className="text-slate-500 font-medium">Auto-decaying behavioral data stored in secure hierarchical tiers.</p>
          </div>
          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 px-6 py-3 bg-slate-50 rounded-2xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors border border-slate-100">
              <Download size={16} /> Data Export
            </button>
            <button className="flex items-center gap-2 px-6 py-3 bg-indigo-600 rounded-2xl text-xs font-bold text-white hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100">
              <Zap size={16} /> Conflict Flag Map
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="Query semantic history..."
              className="w-full pl-14 pr-6 py-4 bg-slate-50 border border-transparent rounded-[1.25rem] focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500/20 text-sm transition-all outline-none font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button className="px-8 py-4 bg-slate-50 border border-transparent rounded-[1.25rem] text-slate-600 hover:text-indigo-600 transition-colors flex items-center gap-3">
            <Filter size={20} />
            <span className="text-sm font-bold">Protocol Filters</span>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-slate-50/30">
              <th className="px-10 py-5 text-left text-[10px] font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Protocol Marker</th>
              <th className="px-10 py-5 text-left text-[10px] font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Speaker ID</th>
              <th className="px-10 py-5 text-left text-[10px] font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Distilled Transcript</th>
              <th className="px-10 py-5 text-left text-[10px] font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Decay Tier</th>
              <th className="px-10 py-5 text-right text-[10px] font-bold uppercase tracking-widest text-slate-400 border-b border-slate-100">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {records.map((record) => (
              <tr key={record.id} className="group hover:bg-slate-50/80 transition-all cursor-default">
                <td className="px-10 py-8 whitespace-nowrap">
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-slate-900">
                      {new Date(record.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
                      {new Date(record.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                </td>
                <td className="px-10 py-8 whitespace-nowrap">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold ${
                      record.isAnonymized ? 'bg-slate-100 text-slate-400 border border-slate-200' : 'bg-indigo-100 text-indigo-700 border border-indigo-200'
                    }`}>
                      {record.speaker === 'System' ? 'SY' : record.speaker.charAt(0)}
                    </div>
                    <span className={`text-sm font-bold ${record.isAnonymized ? 'text-slate-400' : 'text-slate-800'}`}>
                      {record.isAnonymized ? '[ANONYMIZED]' : record.speaker}
                    </span>
                  </div>
                </td>
                <td className="px-10 py-8 min-w-[340px] max-w-md">
                  <div className="flex flex-col gap-1">
                    <p className={`text-sm leading-relaxed ${record.tier === MemoryTier.TIER_3_VAULT ? 'font-mono text-indigo-600' : 'text-slate-600'}`}>
                      {record.tier === MemoryTier.TIER_3_VAULT ? `[VECTOR]: ${record.content.substring(0, 60)}...` : record.content}
                    </p>
                    {record.hasConflictFlag && (
                      <div className="flex items-center gap-1.5 text-rose-500 mt-2">
                        <Zap size={12} fill="currentColor" />
                        <span className="text-[10px] font-black uppercase tracking-widest">Escalation Marker</span>
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-10 py-8 whitespace-nowrap">
                  <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg border text-[10px] font-black uppercase tracking-widest ${
                    record.tier === MemoryTier.TIER_1_BUFFER ? 'bg-indigo-50 text-indigo-700 border-indigo-100' :
                    record.tier === MemoryTier.TIER_2_INSIGHT ? 'bg-sky-50 text-sky-700 border-sky-100' :
                    'bg-emerald-50 text-emerald-700 border-emerald-100'
                  }`}>
                    {record.tier === MemoryTier.TIER_1_BUFFER && <Clock size={12} />}
                    {record.tier === MemoryTier.TIER_2_INSIGHT && <ShieldCheck size={12} />}
                    {record.tier === MemoryTier.TIER_3_VAULT && <ShieldAlert size={12} />}
                    {record.tier.split('_')[1]}
                  </div>
                </td>
                <td className="px-10 py-8 text-right whitespace-nowrap">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    {record.tier === MemoryTier.TIER_1_BUFFER ? 'Decay in 38h' : 'Stable'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {records.length === 0 && (
        <div className="p-20 flex flex-col items-center justify-center text-slate-300 opacity-50">
          <Database size={48} className="mb-4" />
          <p className="text-lg font-bold">No active memory buffer</p>
        </div>
      )}
    </div>
  );
};

export default FactLedger;
