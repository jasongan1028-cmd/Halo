import React, { useState, useRef, useEffect } from 'react';
import { PortalMessage } from '../types';
import { Send, Image, Shield, Sparkles, FileSearch, Mic, MicOff, Volume2, Loader2 } from 'lucide-react';

interface UnifiedPortalProps {
  messages: PortalMessage[];
  onSendMessage: (text: string, isPrivate: boolean, file?: File) => Promise<void>;
  onSpeakText: (text: string) => Promise<void>;
  isSpeaking: boolean;
}

const UnifiedPortal: React.FC<UnifiedPortalProps> = ({ messages, onSendMessage, onSpeakText, isSpeaking }) => {
  const [inputValue, setInputValue] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Initialize Web Speech API for STT
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(prev => prev + (prev ? ' ' : '') + transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      setIsListening(true);
      recognitionRef.current?.start();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() && !isAnalyzing) return;
    
    const text = inputValue;
    const privateTag = isPrivate || text.toLowerCase().startsWith('private');
    
    setInputValue('');
    await onSendMessage(text, privateTag);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsAnalyzing(true);
    await onSendMessage(`Summon: Forensic Evidence Upload`, false, file);
    setIsAnalyzing(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div className="glass rounded-[2.5rem] border border-white/10 flex flex-col h-[550px] overflow-hidden shadow-2xl relative">
      <div className="px-8 py-5 border-b border-white/5 flex justify-between items-center bg-white/5 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/20 rounded-lg text-indigo-400">
            <Sparkles size={18} />
          </div>
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-widest">ASK ME ANYTHING</h3>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter italic">Vent, Verify, or Summon</p>
          </div>
        </div>
        <button 
          onClick={() => setIsPrivate(!isPrivate)}
          className={`px-4 py-2 rounded-xl border text-[9px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
            isPrivate ? 'bg-indigo-600 border-indigo-400 text-white shadow-lg shadow-indigo-500/30' : 'bg-white/5 border-white/10 text-slate-500'
          }`}
        >
          <Shield size={12} /> {isPrivate ? 'Tree Hole: PRIVATE' : 'The Summon: PUBLIC'}
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-6 scrollbar-hide">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} animate-in fade-in slide-in-from-bottom-2`}>
            <div className="flex items-center gap-2 mb-1 px-2">
               <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">
                 {msg.role === 'halo' ? 'HALO' : 'User'} {msg.isPrivate && '• Private Sanctuary'}
               </span>
               {msg.role === 'halo' && msg.type !== 'status' && (
                 <button 
                   onClick={() => onSpeakText(msg.text)} 
                   disabled={isSpeaking}
                   className="p-1 text-slate-500 hover:text-indigo-400 transition-colors disabled:opacity-30"
                 >
                   {isSpeaking ? <Loader2 size={12} className="animate-spin" /> : <Volume2 size={12} />}
                 </button>
               )}
            </div>
            <div className={`max-w-[90%] p-4 rounded-[1.5rem] text-sm leading-relaxed relative ${
              msg.role === 'halo' 
                ? 'bg-indigo-500/10 text-indigo-100 border border-indigo-500/20 shadow-lg' 
                : 'bg-white/10 text-white border border-white/10'
            } ${msg.isPrivate ? 'border-dashed border-indigo-500/40' : ''}`}>
              {msg.text}
              {msg.analysis && (
                <div className="mt-3 pt-3 border-t border-white/5 text-xs text-indigo-300 font-medium">
                  <div className="flex items-center gap-2 mb-1 font-black uppercase tracking-widest text-[10px]">
                    <FileSearch size={12} /> forensic_distillation_result
                  </div>
                  {msg.analysis}
                </div>
              )}
            </div>
          </div>
        ))}
        {isAnalyzing && (
          <div className="flex items-start gap-4 animate-pulse">
            <div className="p-4 bg-indigo-500/5 rounded-2xl border border-indigo-500/10 text-xs text-indigo-300 italic">
              HALO is distilling multimodal evidence artifacts...
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="p-6 bg-slate-950/50 border-t border-white/5 backdrop-blur-xl">
        <div className="relative group">
          <input 
            type="text" 
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Vent, Verify, or Summon..."
            className="w-full bg-white/5 border border-white/10 rounded-[1.5rem] pl-6 pr-40 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:bg-white/10 transition-all placeholder:text-slate-600 font-medium"
          />
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
            <button 
              type="button"
              onClick={toggleListening}
              className={`p-2.5 rounded-xl transition-all ${
                isListening 
                  ? 'bg-rose-500/20 text-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.3)] animate-pulse' 
                  : 'text-slate-500 hover:text-white hover:bg-white/10'
              }`}
              title="Voice Input"
            >
              {isListening ? <MicOff size={20} /> : <Mic size={20} />}
            </button>
            <button 
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 text-slate-500 hover:text-white transition-colors hover:bg-white/10 rounded-xl"
              title="Upload Evidence"
            >
              <Image size={20} />
            </button>
            <button 
              type="submit"
              className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-lg shadow-indigo-500/20 hover:scale-105 active:scale-95 transition-all"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
        <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
        <p className="mt-3 text-[9px] font-black text-slate-600 uppercase tracking-widest text-center">
          {isPrivate ? "SANCTUARY MODE: Data remains local and encrypted" : "MEDIATOR MODE: Synced to Relationship Ledger"}
        </p>
      </form>
    </div>
  );
};

export default UnifiedPortal;