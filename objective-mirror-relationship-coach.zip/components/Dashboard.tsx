
import React from 'react';
import { MetricPoint, Intervention, EvidenceItem, PortalMessage } from '../types';
import HaloRing from './HaloRing';
import UnifiedPortal from './UnifiedPortal';
import { 
  HeartPulse, Zap, FileSearch, Scale, BookOpen, AlertCircle, Plane
} from 'lucide-react';

interface DashboardProps {
  metrics: MetricPoint[];
  interventions: Intervention[];
  evidence: EvidenceItem[];
  portalMessages: PortalMessage[];
  onSendMessage: (text: string, isPrivate: boolean, file?: File) => Promise<void>;
  onSpeakText: (text: string) => Promise<void>;
  isSpeaking: boolean;
  stressLevel: number;
  vibeScore: number;
  mode: any;
  travelFundBalance: number;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  metrics, interventions, evidence, portalMessages, onSendMessage, onSpeakText, isSpeaking,
  stressLevel, vibeScore, mode, travelFundBalance 
}) => {
  const topRules = [
    { title: 'Sarcasm-Free Zone', desc: 'Communication Rule #3' },
    { title: 'Sunday Trash Protocol', desc: 'Labor Equity Rule #1' },
    { title: 'Emotional Transparency', desc: 'Sentiment Rule #4' }
  ];

  return (
    <div className="grid grid-cols-12 gap-8 animate-in fade-in slide-in-from-bottom-6 duration-700">
      
      {/* Left: Forensic & Biometrics */}
      <div className="col-span-12 lg:col-span-3 space-y-8">
        <div className="glass p-6 rounded-[2rem] border border-white/5 shadow-xl bg-teal-500/5">
          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-2">
            <Plane size={14} className="text-teal-400" /> Shared Travel Fund
          </h4>
          <div className="text-center py-4">
            <p className="text-4xl font-black text-white tracking-tighter tabular-nums">${travelFundBalance}</p>
            <p className="text-[9px] font-black text-teal-400 uppercase tracking-widest mt-2">Invested in Future Harmony</p>
          </div>
        </div>

        <div className="glass p-6 rounded-[2rem] border border-white/5 shadow-xl">
          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-2">
            <HeartPulse size={14} className="text-rose-500" /> Physiological Feed
          </h4>
          <div className="space-y-4">
             <BiometricRow label="HRV Variance" value="58ms" status="Secure" color="text-teal-400" />
             <BiometricRow label="Vocal Strain" value="Level" status="Neutral" color="text-indigo-400" />
             <BiometricRow label="Conflict Index" value="0.04" status="Low" color="text-teal-400" />
          </div>
        </div>

        <div className="glass p-6 rounded-[2rem] border border-white/5 shadow-xl">
          <div className="flex justify-between items-center mb-6">
            <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
              <FileSearch size={14} className="text-indigo-400" /> The Evidence Tray
            </h4>
          </div>
          <div className="space-y-4">
            {evidence.length === 0 ? (
              <p className="text-[10px] text-slate-600 italic text-center py-6 border border-dashed border-white/5 rounded-2xl">Awaiting artifact uploads...</p>
            ) : (
              evidence.slice(0, 3).map(item => (
                <div key={item.id} className="group relative rounded-2xl overflow-hidden border border-white/10 hover:border-indigo-500/50 transition-all cursor-pointer">
                  <img src={item.imageUrl} className="w-full h-24 object-cover opacity-60 group-hover:opacity-100 transition-opacity" alt="Forensic Artifact" />
                  <div className="absolute inset-x-0 bottom-0 p-3 bg-slate-900/90 backdrop-blur-sm border-t border-white/10">
                    <div className="flex flex-wrap gap-1">
                      {item.analysisTags.map(tag => (
                        <span key={tag} className="text-[8px] font-black uppercase tracking-widest text-indigo-300 bg-indigo-500/20 px-1.5 py-0.5 rounded">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Center: The Heart (Ring + Portal) */}
      <div className="col-span-12 lg:col-span-6 flex flex-col items-center gap-12">
        <div className="relative">
          <HaloRing stressLevel={stressLevel} vibeScore={vibeScore} mode={mode} />
          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 glass px-4 py-1.5 rounded-xl border border-white/10 text-[9px] font-black text-white uppercase tracking-widest shadow-2xl">
            Vibe Score Sync
          </div>
        </div>
        
        <div className="w-full relative">
          <div className="absolute -top-6 left-8 text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
             <AlertCircle size={12} className="text-indigo-500" /> ASK ME ANYTHING Portal
          </div>
          <UnifiedPortal 
            messages={portalMessages} 
            onSendMessage={onSendMessage} 
            onSpeakText={onSpeakText} 
            isSpeaking={isSpeaking}
          />
        </div>
      </div>

      {/* Right: Constitution & Agentic Log */}
      <div className="col-span-12 lg:col-span-3 space-y-8">
        <div className="glass p-8 rounded-[2.5rem] border border-white/5 shadow-xl bg-indigo-500/5 relative overflow-hidden group">
          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-2">
            <BookOpen size={14} className="text-indigo-400" /> Active Framework
          </h4>
          <div className="space-y-6">
            {topRules.map((rule, i) => (
              <div key={i} className="space-y-1 relative pl-6 border-l-2 border-indigo-500/30">
                <div className="absolute left-[-5px] top-1 w-2 h-2 rounded-full bg-indigo-500" />
                <p className="text-xs font-black text-white uppercase tracking-tight">{rule.title}</p>
                <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{rule.desc}</p>
              </div>
            ))}
          </div>
          <button className="w-full mt-8 py-3 glass bg-white/5 hover:bg-white/10 rounded-xl text-[9px] font-black uppercase tracking-widest text-indigo-400 border border-indigo-500/20 transition-all">
             Full Protocol List
          </button>
        </div>

        <div className="glass p-8 rounded-[2.5rem] border border-white/5 shadow-xl flex flex-col h-[350px]">
          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-2">
            <Zap size={14} className="text-amber-500" /> Agentic Log
          </h4>
          <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-hide">
            {interventions.length === 0 ? (
              <p className="text-[10px] text-slate-600 italic text-center py-10">No recent behavioral circuit breaks.</p>
            ) : (
              interventions.map(log => (
                <div key={log.id} className="p-4 bg-white/5 border border-white/10 rounded-2xl border-l-4 border-l-amber-500">
                  <p className="text-[10px] text-white font-black mb-1 leading-tight">{log.message}</p>
                  <p className="text-[9px] text-slate-500 italic leading-relaxed">{log.reasoning}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const BiometricRow: React.FC<{ label: string; value: string; status: string; color: string }> = ({ label, value, status, color }) => (
  <div className="flex items-center justify-between border-b border-white/5 pb-3">
    <div>
      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{label}</p>
      <p className="text-sm font-black text-white">{value}</p>
    </div>
    <span className={`text-[9px] font-black uppercase tracking-widest ${color}`}>{status}</span>
  </div>
);

export default Dashboard;
