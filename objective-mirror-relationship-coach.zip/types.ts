
export enum OperatingMode {
  DETECTOR = 'DETECTOR',
  COACH = 'COACH',
  JUDGE = 'JUDGE'
}

export enum MemoryTier {
  TIER_1_BUFFER = 'TIER_1_BUFFER', // 0-48h: High-Res Transcripts
  TIER_2_INSIGHT = 'TIER_2_INSIGHT', // 2-30d: Structured Summaries
  TIER_3_VAULT = 'TIER_3_VAULT' // 30d+: Semantic Patterns
}

export interface User {
  id: string;
  name: string;
  role: string;
  biometricStatus: 'linked' | 'pending' | 'none';
  voiceStatus: 'recorded' | 'pending' | 'none';
  visionStatus: 'mapped' | 'pending' | 'none';
  hrvBaseline: number;
  lastStress: number;
}

export interface BiometricMetrics {
  bpm: number;
  hrv: number; // Heart Rate Variability
  activityLevel: number; // 0-1 (Accelerometer proxy)
  isFightOrFlight: boolean;
}

export interface MetricPoint {
  timestamp: number;
  stressLevel: number;
  vibeScore: number; // 0-100: Household Harmony
  volumeLevel: number;
  volatilityIndex: number; // 0-10 scale
  sentiment: 'positive' | 'neutral' | 'negative' | 'escalating';
  biometrics?: BiometricMetrics;
}

export interface FactRecord {
  id: string;
  timestamp: string;
  speaker: string;
  content: string;
  context?: string;
  tier: MemoryTier;
  hasConflictFlag: boolean;
  isAnonymized: boolean;
}

export interface TravelFundEntry {
  id: string;
  timestamp: string;
  amount: number;
  reason: string;
  ruleViolated?: string;
}

export interface Intervention {
  id: string;
  timestamp: string;
  type: 'nudge' | 'circuit_breaker' | 'receipt' | 'preemptive_mediation' | 'biometric_cooldown' | 'travel_fund_alert';
  reasoning: string;
  message: string;
  volatilitySnapshot: number;
  biometricTrigger?: string;
  travelFundImpact?: number;
}

export interface PortalMessage {
  id: string;
  timestamp: string;
  text: string;
  role: 'user' | 'halo';
  isPrivate: boolean;
  type: 'vent' | 'summon' | 'status';
  analysis?: string;
}

export interface EvidenceItem {
  id: string;
  timestamp: string;
  imageUrl: string;
  type: 'screenshot' | 'photo';
  analysisTags: string[];
  findings: string;
}
